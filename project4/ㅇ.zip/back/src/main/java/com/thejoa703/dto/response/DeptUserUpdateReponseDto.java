package com.thejoa703.dto.response;

import lombok.Getter;
import lombok.Setter;

//DeptUserUpdateRequestDto.java
@Getter
@Setter
public class DeptUserUpdateReponseDto {
 private String dname;
 private String loc;

 // getter, setter
}
