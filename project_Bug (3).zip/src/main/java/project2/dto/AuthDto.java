package project2.dto;

import lombok.Data;

@Data
public class AuthDto {
	private String email;
	private String auth;
}
