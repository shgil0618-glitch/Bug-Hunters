package project2.dto;

import java.sql.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecipeDto {
    private int recipeId;
    private int appUserId;       // BUG.APPUSERID 참조
    private String title;
    private int category;        // 카테고리 ID (숫자)
    private String image;
    private int cookTime;
    private String difficulty;
    private int servings;
    private String description;
    private String instructions;
    private Date createdAt;
    private Date updatedAt;
    private int views;
    private String nickname;     // 작성자 닉네임

    private String categoryName; // 카테고리 이름 추가 (조회 시 설정)

    // 연관 객체
    private List<RecipeImage> images;
    private List<RecipeIngre> ingredients;

    // getter/setter (Lombok이 자동으로 생성)
}
