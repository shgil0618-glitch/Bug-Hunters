package project2.dao;

public @interface MyDao {
}
