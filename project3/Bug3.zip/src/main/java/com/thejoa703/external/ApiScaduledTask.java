package com.thejoa703.external;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class ApiScaduledTask {
/*
	@Scheduled(fixedRate = 5000)
	public void runTask1() {
		System.out.println("......스케줄러 실행중 : " + System.currentTimeMillis());
	}

	//@Scheduled(fixedDelay="0 0 10 * * ?") 어떤 작업이 끝난 후에 지정된 시간에 시행
	@Scheduled(cron="0 39 12 * * ?") // 초 분 시 날짜 
	public void runTesk2() {
		System.out.println("......스케줄러 실행중 : " + System.currentTimeMillis());
	}
	cron="0 0 12 * * ?"   0초 0분 12시 일 월 요일
	cron="0 39 12 * * ?"  매일 오후 6시 30분
	cron="0 0 0 ? * MON"   매주 월요일 자정
	
	* 제한없는 모든 값
	? 특정값 없음
*/	
}
/*
- 스케줄링
- naver 개발자 (api 보기 기본)
- mail
- 크롤링
- map
- chatgpt ★
- coolsms
- kakaopay
.....
*/